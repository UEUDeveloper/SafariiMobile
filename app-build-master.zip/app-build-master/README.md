# app-build
Contains the file required to build and realase a file for Ionic Platfrom 
